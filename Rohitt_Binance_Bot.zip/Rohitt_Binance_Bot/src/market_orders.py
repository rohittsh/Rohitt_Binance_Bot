import sys
from binance.client import Client
from src.utils import get_binance_client, validate_order_input
from src.logger import setup_logger

logger = setup_logger()

def place_market_order(symbol, side, quantity):
    client = get_binance_client()
    try:
        validate_order_input(symbol, quantity)
        order = client.futures_create_order(
            symbol=symbol,
            side=side.upper(),
            type='MARKET',
            quantity=quantity
        )
        logger.info(f"Market Order placed: {order}")
    except Exception as e:
        logger.error(f"Error placing market order: {e}")

if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Usage: python market_orders.py SYMBOL BUY/SELL QUANTITY")
        sys.exit(1)
    _, symbol, side, quantity = sys.argv
    place_market_order(symbol.upper(), side.upper(), float(quantity))
