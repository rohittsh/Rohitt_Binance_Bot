from binance.client import Client

def get_binance_client():
    return Client(api_key='your_api_key', api_secret='your_api_secret')

def validate_order_input(symbol, quantity, price=None):
    if not symbol.endswith("USDT"):
        raise ValueError("Only USDT-M pairs are allowed.")
    if quantity <= 0:
        raise ValueError("Quantity must be positive.")
    if price is not None and float(price) <= 0:
        raise ValueError("Price must be positive.")
