import sys
from binance.client import Client
from src.utils import get_binance_client, validate_order_input
from src.logger import setup_logger

logger = setup_logger()

def place_limit_order(symbol, side, quantity, price):
    client = get_binance_client()
    try:
        validate_order_input(symbol, quantity, price)
        order = client.futures_create_order(
            symbol=symbol,
            side=side.upper(),
            type='LIMIT',
            timeInForce='GTC',
            quantity=quantity,
            price=price
        )
        logger.info(f"Limit Order placed: {order}")
    except Exception as e:
        logger.error(f"Error placing limit order: {e}")

if __name__ == "__main__":
    if len(sys.argv) != 5:
        print("Usage: python limit_orders.py SYMBOL BUY/SELL QUANTITY PRICE")
        sys.exit(1)
    _, symbol, side, quantity, price = sys.argv
    place_limit_order(symbol.upper(), side.upper(), float(quantity), str(price))
